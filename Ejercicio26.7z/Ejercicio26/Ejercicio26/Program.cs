﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio26
{
    class Program
    {
        static void Main(string[] args)
        {
            const int CANT = 20, MIN = -500, MAX = 500;
            int[] numerosEnteros = new int[CANT];
            Random rnd = new Random(DateTime.Now.Millisecond);
            int i, j, aux = 0;

            for (i = 0; i < numerosEnteros.Length; i++)
            {
                do
                {
                    numerosEnteros[i] = rnd.Next(MIN, MAX);
                } while (numerosEnteros[i] == 0);
            }


            for (i = 0; i < numerosEnteros.Length; i++)
            {
                Console.WriteLine("Numero: {0}", numerosEnteros[i]);
            }

           
            numerosEnteros = numerosEnteros.OrderByDescending(c => c).ToArray();
            //Array.Sort(numerosEnteros);
            //Array.Reverse(numerosEnteros);
            Console.WriteLine("POSITIVOS");
            for (i = 0; i < numerosEnteros.Length; i++)
            {
                if(numerosEnteros[i]>0)
                Console.WriteLine("Numero ordenado: {0}", numerosEnteros[i]);
            }

            Array.Reverse(numerosEnteros);
            Console.WriteLine("negativos");
            for (i = 0; i < numerosEnteros.Length; i++)
            {
                if (numerosEnteros[i] < 0)
                    Console.WriteLine("Numero ordenado: {0}", numerosEnteros[i]);
            }

            Console.ReadKey();
        }
    }
}
