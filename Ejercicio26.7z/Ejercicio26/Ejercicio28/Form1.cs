﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio28
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            Dictionary<string, int> dictionary = new Dictionary<string, int>();
            string[] palabras;
            char[] separadores = { ' ', ',', '.', ':',';', '\n' };
            int aux;
            palabras = rtbPalabras.Text.Split(separadores);
            foreach (string palabra in palabras)
            {
                if (!dictionary.ContainsKey(palabra))
                {
                    dictionary.Add(palabra, 1);
                }
                else
                {
                    aux = dictionary[palabra];
                    aux += 1;
                    dictionary[palabra] = aux;
                }
            }

            StringBuilder sb = new StringBuilder();

            foreach(KeyValuePair<string,int> str in dictionary)
            {
                sb.AppendFormat("palabra: {0} veces: {1}", str.Key, str.Value.ToString());
                sb.AppendLine();
            }
            MessageBox.Show(sb.ToString());
        }
    }
}
