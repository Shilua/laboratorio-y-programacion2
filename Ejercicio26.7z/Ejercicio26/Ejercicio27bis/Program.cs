﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ejercicio27console;

namespace Ejercicio27bis
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numeros;
            Queue<int> numeroscola;
            Stack<int> numerospila;
            numeros = new List<int>();
            numeroscola = new Queue<int>();
            numerospila = new Stack<int>();
            Random rnd = new Random(DateTime.Now.Millisecond);
            const int CANT = 20, MIN = -500, MAX = 500;
            int i, num;

            for (i = 0; i < CANT; i++)
            {
                do
                {
                    num = rnd.Next(MIN, MAX);
                } while (num == 0);
                numeros.Add(num);
            }

            numeros.Sort(clase.HigthToLow);

        }
    }
}
