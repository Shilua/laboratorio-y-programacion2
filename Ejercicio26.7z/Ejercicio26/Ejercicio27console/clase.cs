﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio27console
{
    public class clase
    {
        public static int HigthToLow(int a, int b)
        {
            return -(a.CompareTo(b));
        }
    }
}
