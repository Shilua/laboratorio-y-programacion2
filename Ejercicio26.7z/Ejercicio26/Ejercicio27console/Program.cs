﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio27console
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numeros;
            numeros = new List<int>();
            Random rnd = new Random(DateTime.Now.Millisecond);
            const int CANT = 20, MIN = -500, MAX = 500;
            int i, num;

            for (i = 0; i < CANT; i++)
            {
                do
                {
                    num = rnd.Next(MIN, MAX);
                } while (num == 0);
                numeros.Add(num);
            }

            numeros.Sort();

            foreach (int a in numeros)
            {
                if(a<0)
                Console.WriteLine(a);
            }

            numeros.Sort(clase.HigthToLow);

            foreach (int a in numeros)
            {
                if (a > 0)
                    Console.WriteLine(a);
            }

            Console.ReadKey();
        }
    }
}
