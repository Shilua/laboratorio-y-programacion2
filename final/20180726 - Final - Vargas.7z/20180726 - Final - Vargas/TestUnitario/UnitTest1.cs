﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Sofa prueba = new Sofa(10, 10, 10, Sofa.Colores.Blanco);
            Sofa recibe = null;
            ArchivoXML archivo = new ArchivoXML();

            archivo.Guardar(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\asientos.xml", prueba);
           recibe = (Sofa)archivo.Leer(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\asientos.xml");

           Assert.AreNotEqual(prueba,recibe);
        }
    }
}
