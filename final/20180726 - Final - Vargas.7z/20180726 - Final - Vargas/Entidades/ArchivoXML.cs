﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Entidades
{
    public class ArchivoXML : IArchivos<bool,Asiento>
    {
        public bool Guardar(string path, Asiento elemento)
        {
            XmlTextWriter writer;
            XmlSerializer ser;
            StreamWriter strw = new StreamWriter(path);
            writer = new XmlTextWriter(strw.ToString(), Encoding.UTF8);
            ser = new XmlSerializer(typeof(Asiento));
            try
            {
                ser.Serialize(writer, elemento);
                return true;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                writer.Close();
            }
        }

        public Asiento Leer(string path)
        {
            try
            {
                Asiento aux = null;   //Objeto que alojará los datos
                //contenidos en el archivo XML.
                XmlTextReader reader;   //Objeto que leerá XML.
                XmlSerializer ser;            //Objeto que Deserializará.

                reader = new XmlTextReader(path);
                //Se indica ubicación del archivo XML.
                ser = new XmlSerializer(typeof(Asiento));
                //Se indica el tipo de objeto ha serializar.
                aux = (Asiento)ser.Deserialize(reader);
                //Deserializa el archivo contenido en reader, lo guarda 
                //en aux.
                reader.Close();
                return aux;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
