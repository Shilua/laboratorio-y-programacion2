﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ArchivoTexto: IArchivos<bool,string>
    {

        public bool Guardar(string path, string elemento)
        {
            try
            {
                using (System.IO.StreamWriter file = new System.IO.StreamWriter(path, true)) //append
                {
                    file.WriteLine(elemento.ToString());
                    
                    file.Close();
                }
                return true;
            }
            catch (Exception e)
            {
                throw e;               
            }
        }

        public string Leer(string path)
        {
            string retorno;
            StreamReader lectura = new StreamReader(path);
            retorno = lectura.ReadToEnd();
            lectura.Close();
            return retorno;
        }


        
    }
}
