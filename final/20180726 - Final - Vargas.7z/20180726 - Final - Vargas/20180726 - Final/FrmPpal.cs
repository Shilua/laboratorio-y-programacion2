﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.Threading;

namespace _20180726___Final
{
    // Reutilizar tanto código como sea posible.
    // Primer Parcial: Agregar un atributo del tipo Muebleria e instanciarlo en el constructor.
    // Segundo Parcial y Final
    //   - Agregar un atributo del tipo Lista de Asiento e instanciarlo en el constructor.
    //   - Controlar excepciones en archivos.
    //   - Para el manejo de archivos agregar una interfaz genérica con los métodos V Guardar(string path, T elemento) y T Leer(string path)
    //   - Generar dos clases: ArchivoTexto y ArchivoXML que implementen dicha interfaz. Completar los métodos según corresponda.
    //   - Probar todos los asientos mediante un Thread. Crear un evento FinPruebaCalidad() en Asiento para que informe si la prueba pasó (true) o no (false) y mostrar el resultado por pantalla.
    public partial class FrmPpal : Form
    {
        List<Asiento> lista;

        public FrmPpal()
        {
            InitializeComponent();

            this.lista = new List<Asiento>();
        }

        /// <summary>
        /// Primer Parcial: Agregar el elemento a la mueblería.
        /// Segundo Parcial y Final: Al presionar el botón agregar se deberá guardar la información a un archivo, anexando el nuevo Asiento al final. Agregar el elemento a la lista.
        /// Luego, leer el archivo y mostrarlo en el RichTextBox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            int random  = r.Next(0,3);
            Sofa.Colores color = Sofa.Colores.Blanco;
            switch(random)
            {
                case 0:
                    color = Sofa.Colores.Blanco;
                    break;
                case 1:
                    color = Sofa.Colores.Natural;
                    break;
                case 2:
                    color = Sofa.Colores.Negro;
                    break;
                case 3:
                    color = Sofa.Colores.Rojo;
                    break;
            }
            Sofa nuevoAsiento = new Sofa(short.Parse(nudAlto.Value.ToString()), short.Parse(nudAncho.Value.ToString()), short.Parse(nudProfundidad.Value.ToString()), color);
            ArchivoTexto nuevo = new ArchivoTexto();
            nuevo.Guardar(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\asientos.txt", nuevoAsiento.ToString());
            this.lista.Add(nuevoAsiento);
            rtbMensaje.Text = nuevo.Leer(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\asientos.txt");

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Al abrir el programa se deberá leer el archivo y mostrarlo en el RichTextBox
            
            ArchivoTexto nuevo = new ArchivoTexto();
            rtbMensaje.Text = nuevo.Leer(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\asientos.txt");
        }

        /// <summary>
        /// Antes de cerrar, serializar la lista en XML. Hacer las modificaciones necesarias para guardar todos los datos.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            ArchivoXML archivo = new ArchivoXML();
            string path = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory) + "\\asientos.xml";
            foreach (Asiento aux in this.lista)
            {
                archivo.Guardar(path, aux);
            }
        }

        private void MetodoDePrueva()
        {
            foreach (Asiento aux in this.lista)
            {
                aux.FinPruebaCalidad += ManejadorPrueba;
                aux.ProbarAsiento();
                
            }
        }

        private void btnProbar_Click(object sender, EventArgs e)
        {
            Thread probar = new Thread(MetodoDePrueva);
            
        }

        private void ManejadorPrueba(bool probar)
        {
            MessageBox.Show("{0}", probar.ToString());
        }
    }
}
