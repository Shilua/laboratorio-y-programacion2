﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using Excepciones;

namespace Entidades
{
    public class SerializarBinaria : IArchivos<Votacion>
    {

        public SerializarBinaria()
        {
        }

        public Votacion Leer(string nombre)
        {   
            Votacion aux = null;
            try
            {
                
                FileStream fs;
                BinaryFormatter ser;

                fs = new FileStream(nombre, FileMode.Open);
                ser = new BinaryFormatter();

                aux = (Votacion)ser.Deserialize(fs);               
            }
            catch (Exception)
            {
                throw new ErrorArchivoException("No pudo leer el archivo binario");
            }
            return aux;
        }

        public bool Guardar(string nombre, Votacion objeto)
        {
            bool retorno;
            try
            {
                FileStream fs;
                BinaryFormatter ser;

                fs = new FileStream(nombre, FileMode.OpenOrCreate);
                ser = new BinaryFormatter();

                ser.Serialize(fs, objeto);
                retorno = true;
                
            }
            catch (Exception)
            {
                retorno = false;
                throw new ErrorArchivoException("No pudo guardar el archivo binario");
            }
            return retorno;
            
        }
    }
}
