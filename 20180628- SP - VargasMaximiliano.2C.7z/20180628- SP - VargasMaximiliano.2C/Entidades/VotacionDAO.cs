﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class VotacionDAO : IArchivos<Votacion>
    {
        private static SqlConnection conexion;
        private static SqlCommand comando;

        public VotacionDAO()
        {
            conexion = new SqlConnection(Properties.Settings.Default.conexionDB);
            comando = new SqlCommand();

            VotacionDAO.comando.CommandType = System.Data.CommandType.Text;
            VotacionDAO.comando.Connection = VotacionDAO.conexion;
        }

        public Votacion Leer(string nombre)
        {
            throw new NotImplementedException();
        }

        public bool Guardar(string nombre, Votacion objeto)
        {
            
            bool retorno = false;
            string sql = string.Format("INSERT INTO {0} (nombreLey,afirmativos,negativos,abstenciones,nombreAlumno) VALUES('{1},'{2}','{3}','{4}','Vargas.Maximiliano)", nombre, objeto.NombreLey, objeto.ContadorAfirmativo, objeto.ContadorNegativo, objeto.ContadorAbstencion);
            try
            {
                retorno = EjecutarNonQuery(sql);
            }
            catch (Exception e)
            {
                throw e;
            }
            return retorno;
        }

        private static bool EjecutarNonQuery(string sql)
        {
            bool todoOk = false;
            try
            {
                // LE PASO LA INSTRUCCION SQL
                VotacionDAO.comando.CommandText = sql;

                // ABRO LA CONEXION A LA BD
                VotacionDAO.conexion.Open();

                // EJECUTO EL COMMAND
                VotacionDAO.comando.ExecuteNonQuery();

                todoOk = true;
            }
            catch (Exception e)
            {
                todoOk = false;
            }
            finally
            {
                if (todoOk)
                    VotacionDAO.conexion.Close();
            }
            return todoOk;
        }
    }
}
