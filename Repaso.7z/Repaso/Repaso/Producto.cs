﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    public class Producto
    {
        protected string codigoDeBarra;
        protected string marca;
        protected float precio;

        public Producto(string marca, string codigo, float precio)
        {
            this.marca = marca;
            this.codigoDeBarra = codigo;
            this.precio = precio;
        }


        public static explicit operator string(Producto p)
        {
            return p.codigoDeBarra;
        }

        public float getPrecio()
        {
            return this.precio;
        }

        public string getMarca()
        {
            return this.marca;
        }

        public static string MostrarProducto(Producto p)
        {
            string returnAux = "";
            return returnAux;
        }

        public static bool operator !=(Producto p, string marca)
        {
            bool returnBool = false;
            if (p.marca != marca)
            {
                returnBool = true;
            }
            return returnBool;
        }

        public static bool operator ==(Producto p, string marca)
        {
            bool returnBool = false;
            if (p.marca == marca)
            {
                returnBool = true;
            }
            return returnBool;
        }

        public static bool operator !=(Producto p1, Producto p2)
        {
            bool returnBool = false;
            if (p1.marca != p2.marca && p1.codigoDeBarra != p2.codigoDeBarra)
            {
                returnBool = true;
            }
            return returnBool;
        }

        public static bool operator ==(Producto p1, Producto p2)
        {
            bool returnBool = false;
            if (p1.marca == p2.marca && p1.codigoDeBarra == p2.codigoDeBarra)
            {
                returnBool = true;
            }
            return returnBool;
        }

    }
}
