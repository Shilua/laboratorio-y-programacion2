﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso
{
    class Estante
    {
        private Producto[] productos;
        private int ubicacionEstante;

        private Estante(int capacidad)
        {
            this.productos = new Producto[capacidad];
        }

        public Estante(int capacidad, int ubicacion) : this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }

        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public static bool operator ==(Estante e, Producto p)
        {
            bool returnBool = false;
            int i;

            for (i = 0; i < e.productos.Length-1; i++)
            {
                if (e.productos[i] == p)
                {
                    returnBool = true;
                    break;
                }
            }
            return returnBool;
        }

        public static bool operator !=(Estante e, Producto p)
        {
            bool returnBool = true;
            int i;

            for (i = 0; i < e.productos.Length; i++)
            {
                if (e.productos[i] == p)
                {
                    returnBool = false;
                    break;
                }
            }
            return returnBool;
        }

        public static bool operator +(Estante e, Producto p)
        {
            bool returnBool = false;
            int i;
            if (e != p)
            {
                for (i = 0; i < e.productos.Length; i++)
                {
                   if(!Object.ReferenceEquals(e.productos[i],null))
                   {
                       e.productos[i] = p;
                   }
                }
            }

            return returnBool;
        }

        public static Estante operator -(Estante e, Producto p)
        {
            
            int i;
            if (e == p)
            {
                for (i = 0; i < e.productos.Length; i++)
                {
                    if (Object.ReferenceEquals(e.productos[i], p))
                    {
                        e.productos[i] = null;
                    }
                }
            }

            return e;
        }

    }
}
